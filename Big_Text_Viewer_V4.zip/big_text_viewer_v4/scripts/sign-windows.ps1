param(
    [Parameter(Mandatory=$true)] [string]$CertificatePath,
    [Parameter(Mandatory=$true)] [SecureString]$CertificatePassword,
    [string]$InputFile = "dist\Big Text Viewer V4.exe",
    [string]$TimestampUrl = "http://timestamp.digicert.com"
)

$ErrorActionPreference = "Stop"
if (-not (Get-Command signtool.exe -ErrorAction SilentlyContinue)) {
    throw "找不到 signtool.exe。請安裝 Windows SDK，並在 Developer PowerShell 執行。"
}
if (-not (Test-Path $InputFile)) { throw "找不到輸入檔案：$InputFile" }
if (-not (Test-Path $CertificatePath)) { throw "找不到憑證：$CertificatePath" }

$ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($CertificatePassword)
try {
    $plainPassword = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr)
    & signtool.exe sign /fd SHA256 /td SHA256 /tr $TimestampUrl /f $CertificatePath /p $plainPassword $InputFile
    if ($LASTEXITCODE -ne 0) { throw "簽章失敗，SignTool 結束碼：$LASTEXITCODE" }
    & signtool.exe verify /pa /v $InputFile
    if ($LASTEXITCODE -ne 0) { throw "簽章驗證失敗，SignTool 結束碼：$LASTEXITCODE" }
}
finally {
    if ($ptr -ne [IntPtr]::Zero) { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr) }
}
